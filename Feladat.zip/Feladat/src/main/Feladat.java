
package main;

import java.awt.Color;


public class Feladat extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(Feladat.class.getName());
    
    private String[] ozslop0 = {"P","K","Z","O"};
    private String[] ozslop1 = {"Z","P","K","O"};
    private String[] ozslop2 = {"K","Z","P","O"};
    private String[] ozslop3 = {"O","O","O","O"};
    
    private int utu0;
    private int utu1;
    private int utu2;
    private int utu3;
    
    private int f;
    private int e;
    
    private String taroltpoz = "";
    
    private int hely;
    public Feladat() {
        initComponents();
    }


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        buttonGroup2 = new javax.swing.ButtonGroup();
        tart01 = new javax.swing.JButton();
        tart02 = new javax.swing.JButton();
        tart03 = new javax.swing.JButton();
        tart11 = new javax.swing.JButton();
        tart12 = new javax.swing.JButton();
        tart13 = new javax.swing.JButton();
        tart31 = new javax.swing.JButton();
        tart32 = new javax.swing.JButton();
        tart33 = new javax.swing.JButton();
        tart21 = new javax.swing.JButton();
        tart22 = new javax.swing.JButton();
        tart23 = new javax.swing.JButton();
        rbt0f = new javax.swing.JRadioButton();
        rbt0e = new javax.swing.JRadioButton();
        rbt1f = new javax.swing.JRadioButton();
        rbt1e = new javax.swing.JRadioButton();
        rbt3f = new javax.swing.JRadioButton();
        rbt3e = new javax.swing.JRadioButton();
        rbt2f = new javax.swing.JRadioButton();
        rbt2e = new javax.swing.JRadioButton();
        rbt9f = new javax.swing.JRadioButton();
        rbt9e = new javax.swing.JRadioButton();
        btnont = new javax.swing.JButton();
        tart20 = new javax.swing.JButton();
        tart30 = new javax.swing.JButton();
        tart00 = new javax.swing.JButton();
        tart10 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        btnng = new javax.swing.JButton();
        exit = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setResizable(false);

        tart01.setBackground(new java.awt.Color(0, 255, 0));

        tart02.setBackground(new java.awt.Color(0, 0, 255));

        tart03.setBackground(new java.awt.Color(255, 0, 0));

        tart11.setBackground(new java.awt.Color(0, 0, 255));

        tart12.setBackground(new java.awt.Color(255, 0, 0));

        tart13.setBackground(new java.awt.Color(0, 255, 0));

        tart21.setBackground(new java.awt.Color(255, 0, 0));

        tart22.setBackground(new java.awt.Color(0, 255, 0));

        tart23.setBackground(new java.awt.Color(0, 0, 255));

        buttonGroup1.add(rbt0f);
        rbt0f.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbt0fActionPerformed(evt);
            }
        });

        buttonGroup2.add(rbt0e);
        rbt0e.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbt0eActionPerformed(evt);
            }
        });

        buttonGroup1.add(rbt1f);
        rbt1f.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbt1fActionPerformed(evt);
            }
        });

        buttonGroup2.add(rbt1e);
        rbt1e.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbt1eActionPerformed(evt);
            }
        });

        buttonGroup1.add(rbt3f);
        rbt3f.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbt3fActionPerformed(evt);
            }
        });

        buttonGroup2.add(rbt3e);
        rbt3e.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbt3eActionPerformed(evt);
            }
        });

        buttonGroup1.add(rbt2f);
        rbt2f.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbt2fActionPerformed(evt);
            }
        });

        buttonGroup2.add(rbt2e);
        rbt2e.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbt2eActionPerformed(evt);
            }
        });

        buttonGroup1.add(rbt9f);
        rbt9f.setSelected(true);
        rbt9f.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbt9fActionPerformed(evt);
            }
        });

        buttonGroup2.add(rbt9e);
        rbt9e.setSelected(true);
        rbt9e.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbt9eActionPerformed(evt);
            }
        });

        btnont.setText("Önt!");
        btnont.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnontActionPerformed(evt);
            }
        });

        jLabel1.setText("Melyikből");

        jLabel2.setText("Melyikbe");

        btnng.setText("ÚJ játék");

        exit.setText("Exit");
        exit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                exitActionPerformed(evt);
            }
        });

        jLabel3.setFont(new java.awt.Font("sansserif", 0, 48)); // NOI18N
        jLabel3.setText("game or smt");
        jLabel3.setCursor(new java.awt.Cursor(java.awt.Cursor.CROSSHAIR_CURSOR));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(118, 118, 118)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(tart01, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(tart02, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(tart03, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGap(33, 33, 33)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(tart11, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(tart12, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(tart13, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(tart00, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(33, 33, 33)
                                        .addComponent(tart10, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGap(42, 42, 42)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(tart21, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(tart22, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(tart23, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(tart20, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(layout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(exit)))
                        .addGap(33, 33, 33)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(tart31, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tart32, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tart33, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(btnont)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(btnng))
                            .addComponent(tart30, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(49, 49, 49)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(rbt9f)
                            .addComponent(rbt9e))
                        .addGap(70, 70, 70)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(rbt0f)
                            .addComponent(rbt0e))
                        .addGap(95, 95, 95)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(rbt1f)
                            .addComponent(rbt1e))
                        .addGap(89, 89, 89)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(rbt2f)
                            .addComponent(rbt2e))
                        .addGap(95, 95, 95)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(rbt3f)
                            .addComponent(rbt3e))
                        .addGap(71, 71, 71)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel2)
                            .addComponent(jLabel1))
                        .addGap(0, 13, Short.MAX_VALUE)))
                .addContainerGap())
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 488, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(53, 53, 53))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(43, 43, 43)
                .addComponent(jLabel3)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(tart20, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(tart30, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(tart00, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(tart10, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(rbt9f)
                        .addGap(18, 18, 18)
                        .addComponent(rbt9e))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(tart31, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(tart32, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(tart33, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(tart21, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(tart22, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(tart23, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(tart11, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(tart12, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(tart13, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(tart01, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(tart02, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(tart03, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(rbt0f)
                                .addGap(18, 18, 18)
                                .addComponent(rbt0e))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(rbt1f)
                                .addGap(18, 18, 18)
                                .addComponent(rbt1e))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(rbt2f)
                                .addGap(18, 18, 18)
                                .addComponent(rbt2e))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(rbt3f)
                                    .addComponent(jLabel1))
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(rbt3e)
                                    .addComponent(jLabel2))))))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnont)
                    .addComponent(btnng)
                    .addComponent(exit))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void exitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_exitActionPerformed
        System.exit(0);
    }//GEN-LAST:event_exitActionPerformed

    private void rbt0fActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbt0fActionPerformed
    f = 0;
    }//GEN-LAST:event_rbt0fActionPerformed

    private void btnontActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnontActionPerformed
        if (f == 0){
            if (e == 3){
            tart33.setBackground(Color.green);
            tart01.setBackground(null);
            } 
        }
    }//GEN-LAST:event_btnontActionPerformed

    private void rbt9fActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbt9fActionPerformed
    f = -1;
    }//GEN-LAST:event_rbt9fActionPerformed

    private void rbt1fActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbt1fActionPerformed
    f = 1;        // TODO add your handling code here:
    }//GEN-LAST:event_rbt1fActionPerformed

    private void rbt2fActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbt2fActionPerformed
    f = 2;        // TODO add your handling code here:
    }//GEN-LAST:event_rbt2fActionPerformed

    private void rbt3fActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbt3fActionPerformed
    f = 3;        // TODO add your handling code here:
    }//GEN-LAST:event_rbt3fActionPerformed

    private void rbt9eActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbt9eActionPerformed
    e = -1;        // TODO add your handling code here:
    }//GEN-LAST:event_rbt9eActionPerformed

    private void rbt0eActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbt0eActionPerformed
    e = 0;        // TODO add your handling code here:
    }//GEN-LAST:event_rbt0eActionPerformed

    private void rbt1eActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbt1eActionPerformed
    e = 1;        // TODO add your handling code here:
    }//GEN-LAST:event_rbt1eActionPerformed

    private void rbt2eActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbt2eActionPerformed
    e = 2;        // TODO add your handling code here:
    }//GEN-LAST:event_rbt2eActionPerformed

    private void rbt3eActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbt3eActionPerformed
    e = 3;        // TODO add your handling code here:
    }//GEN-LAST:event_rbt3eActionPerformed


    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(() -> new Feladat().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnng;
    private javax.swing.JButton btnont;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.ButtonGroup buttonGroup2;
    private javax.swing.JButton exit;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JRadioButton rbt0e;
    private javax.swing.JRadioButton rbt0f;
    private javax.swing.JRadioButton rbt1e;
    private javax.swing.JRadioButton rbt1f;
    private javax.swing.JRadioButton rbt2e;
    private javax.swing.JRadioButton rbt2f;
    private javax.swing.JRadioButton rbt3e;
    private javax.swing.JRadioButton rbt3f;
    private javax.swing.JRadioButton rbt9e;
    private javax.swing.JRadioButton rbt9f;
    private javax.swing.JButton tart00;
    private javax.swing.JButton tart01;
    private javax.swing.JButton tart02;
    private javax.swing.JButton tart03;
    private javax.swing.JButton tart10;
    private javax.swing.JButton tart11;
    private javax.swing.JButton tart12;
    private javax.swing.JButton tart13;
    private javax.swing.JButton tart20;
    private javax.swing.JButton tart21;
    private javax.swing.JButton tart22;
    private javax.swing.JButton tart23;
    private javax.swing.JButton tart30;
    private javax.swing.JButton tart31;
    private javax.swing.JButton tart32;
    private javax.swing.JButton tart33;
    // End of variables declaration//GEN-END:variables
}
